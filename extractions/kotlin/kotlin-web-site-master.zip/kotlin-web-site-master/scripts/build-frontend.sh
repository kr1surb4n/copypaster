#!/usr/bin/env bash

set -ex

yarn install --frozen-lockfile
yarn run build