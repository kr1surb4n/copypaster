---
title: /docs/security.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/security.html
---

The page is moved to [topics/security.md](../docs/topics/security.md)
