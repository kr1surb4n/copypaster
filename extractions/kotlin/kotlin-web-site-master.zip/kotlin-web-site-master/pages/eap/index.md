---
title: tutorials/spring-boot-restful.md
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/eap.html
---

The page is moved to [topics/eap.md](../../docs/topics/eap.md)
