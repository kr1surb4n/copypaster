---
title: tutorials/spring-boot-restful.md
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/configure-build-for-eap.html
---

The page is moved to [topics/configure-build-for-eap.md](../../docs/topics/configure-build-for-eap.md)
