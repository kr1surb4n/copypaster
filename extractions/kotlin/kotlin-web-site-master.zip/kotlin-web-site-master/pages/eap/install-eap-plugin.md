---
title: tutorials/spring-boot-restful.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/install-eap-plugin.html
---

The page is moved to [topics/install-eap-plugin.md](../../docs/topics/install-eap-plugin.md)
