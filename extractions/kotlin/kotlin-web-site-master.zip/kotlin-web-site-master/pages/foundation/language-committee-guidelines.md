---
title: /docs/language-committee-guidelines.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/language-committee-guidelines.html
---

The page is moved to [topics/language-committee-guidelines.md](../../docs/topics/language-committee-guidelines.md)
