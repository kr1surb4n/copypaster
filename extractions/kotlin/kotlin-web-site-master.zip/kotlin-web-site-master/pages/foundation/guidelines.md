---
title: /docs/guidelines.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/guidelines.html
---

The page is moved to [topics/guidelines.md](../../docs/topics/guidelines.md)
