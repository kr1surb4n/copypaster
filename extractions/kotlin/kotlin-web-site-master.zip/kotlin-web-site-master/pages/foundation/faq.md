---
title: /docs/foundation-faq.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/foundation-faq.html
---

The page is moved to [topics/foundation-faq.md](../../docs/topics/foundation-faq.md)
