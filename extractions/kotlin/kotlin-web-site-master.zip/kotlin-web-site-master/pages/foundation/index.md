---
title: /docs/kotlin-foundation.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kotlin-foundation.html
---

The page is moved to [topics/kotlin-foundation.md](../../docs/topics/kotlin-foundation.md)
