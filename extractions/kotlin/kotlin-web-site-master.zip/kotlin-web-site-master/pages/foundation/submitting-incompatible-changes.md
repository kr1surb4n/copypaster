---
title: /docs/submitting-incompatible-changes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/submitting-incompatible-changes.html
---

The page is moved to [topics/submitting-incompatible-changes.md](../../docs/topics/submitting-incompatible-changes.md)
