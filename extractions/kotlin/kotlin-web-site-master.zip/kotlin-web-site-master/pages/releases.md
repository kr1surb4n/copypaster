---
title: /docs/releases.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/releases.html
---

The page is moved to [topics/releases.md](../docs/topics/releases.md)
