---
title: docs/reflection.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/reflection.html
---

The page is moved to [topics/reflection.md](docs/topics/reflection.md)
