---
title: docs/mpp-dsl-reference.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-dsl-reference.html
---

The page is moved to [topics/mpp-dsl-reference.md](docs/topics/mpp-dsl-reference.md)
