---
title: docs/iterators.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/iterators.html
---

The page is moved to [topics/iterators.md](docs/topics/iterators.md)
