---
title: docs/kapt.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kapt.html
---

The page is moved to [topics/kapt.md](docs/topics/kapt.md)
