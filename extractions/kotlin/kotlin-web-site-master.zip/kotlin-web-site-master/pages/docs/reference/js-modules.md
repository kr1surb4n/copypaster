---
title: docs/js-modules.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-modules.html
---

The page is moved to [topics/js-modules.md](docs/topics/js-modules.md)
