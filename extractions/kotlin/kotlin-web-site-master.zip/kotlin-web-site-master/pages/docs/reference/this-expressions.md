---
title: docs/this-expressions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/this-expressions.html
---

The page is moved to [topics/this-expressions.md](docs/topics/this-expressions.md)
