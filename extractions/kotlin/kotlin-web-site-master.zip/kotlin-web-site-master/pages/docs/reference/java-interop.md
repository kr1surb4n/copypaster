---
title: docs/java-interop.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/java-interop.html
---

The page is moved to [topics/java-interop.md](docs/topics/java-interop.md)
