---
title: docs/compiler-reference.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/compiler-reference.html
---

The page is moved to [topics/compiler-reference.md](docs/topics/compiler-reference.md)
