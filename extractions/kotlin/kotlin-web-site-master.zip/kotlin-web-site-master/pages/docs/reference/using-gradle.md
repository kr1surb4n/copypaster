---
title: docs/native-gradle.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/gradle.html
---

The page is moved to [topics/native-gradle.md](docs/topics/native-gradle.md)
