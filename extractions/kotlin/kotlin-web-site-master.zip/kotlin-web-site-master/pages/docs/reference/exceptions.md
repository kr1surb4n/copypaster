---
title: docs/exceptions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/exceptions.html
---

The page is moved to [topics/exceptions.md](docs/topics/exceptions.md)
