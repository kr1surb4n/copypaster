---
title: docs/whatsnew11.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew11.html
---

The page is moved to [topics/whatsnew11.md](docs/topics/whatsnew11.md)
