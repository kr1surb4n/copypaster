---
title: docs/visibility-modifiers.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/visibility-modifiers.html
---

The page is moved to [topics/visibility-modifiers.md](docs/topics/visibility-modifiers.md)
