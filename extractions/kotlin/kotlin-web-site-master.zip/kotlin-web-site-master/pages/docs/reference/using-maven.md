---
title: docs/native-maven.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/maven.html
---

The page is moved to [topics/maven.md](docs/topics/maven.md)
