---
title: docs/mpp-supported-platforms.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-supported-platforms.html
---

The page is moved to [topics/mpp-supported-platforms.md](docs/topics/mpp-supported-platforms.md)
