---
title: docs/js-ir-compiler.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-ir-compiler.html
---

The page is moved to [topics/js-ir-compiler.md](docs/topics/js-ir-compiler.md)
