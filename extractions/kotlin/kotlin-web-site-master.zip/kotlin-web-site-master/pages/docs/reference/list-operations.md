---
title: docs/list-operations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/list-operations.html
---

The page is moved to [topics/list-operations.md](docs/topics/list-operations.md)
