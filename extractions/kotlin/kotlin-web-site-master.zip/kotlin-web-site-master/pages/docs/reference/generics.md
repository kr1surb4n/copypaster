---
title: docs/generics.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/generics.html
---

The page is moved to [topics/generics.md](docs/topics/generics.md)
