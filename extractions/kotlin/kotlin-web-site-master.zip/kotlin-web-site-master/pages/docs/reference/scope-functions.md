---
title: docs/scope-functions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/scope-functions.html
---

The page is moved to [topics/scope-functions.md](docs/topics/scope-functions.md)
