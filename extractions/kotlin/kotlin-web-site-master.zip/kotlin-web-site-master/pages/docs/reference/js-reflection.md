---
title: docs/js-reflection.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-reflection.html
---

The page is moved to [topics/js-reflection.md](docs/topics/js-reflection.md)
