---
title: docs/lambdas.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/lambdas.html
---

The page is moved to [topics/lambdas.md](docs/topics/lambdas.md)
