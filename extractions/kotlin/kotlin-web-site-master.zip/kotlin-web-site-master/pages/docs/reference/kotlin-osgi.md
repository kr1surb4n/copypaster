---
title: docs/kotlin-osgi.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kotlin-osgi.html
---

The page is moved to [topics/kotlin-osgi.md](docs/topics/kotlin-osgi.md)
