---
title: docs/returns.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/returns.html
---

The page is moved to [topics/returns.md](docs/topics/returns.md)
