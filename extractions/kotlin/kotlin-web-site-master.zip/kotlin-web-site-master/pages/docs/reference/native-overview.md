---
title: docs/native-overview.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-overview.html
---

The page is moved to [topics/native-overview.md](docs/topics/native-overview.md)
