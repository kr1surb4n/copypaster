---
title: docs/javascript-dce.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/javascript-dce.html
---

The page is moved to [topics/javascript-dce.md](docs/topics/javascript-dce.md)
