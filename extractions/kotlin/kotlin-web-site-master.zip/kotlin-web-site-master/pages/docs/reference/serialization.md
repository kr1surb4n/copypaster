---
title: docs/serialization.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/serialization.html
---

The page is moved to [topics/serialization.md](docs/topics/serialization.md)
