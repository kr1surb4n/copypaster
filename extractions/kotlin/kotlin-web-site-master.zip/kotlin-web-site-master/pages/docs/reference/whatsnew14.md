---
title: docs/whatsnew14.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew14.html
---

The page is moved to [topics/whatsnew14.md](docs/topics/whatsnew14.md)
