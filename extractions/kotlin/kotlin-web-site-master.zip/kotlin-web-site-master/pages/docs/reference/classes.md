---
title: docs/classes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/classes.html
---

The page is moved to [topics/classes.md](docs/topics/classes.md)
