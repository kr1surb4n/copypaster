---
title: docs/whatsnew12.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew12.html
---

The page is moved to [topics/whatsnew12.md](docs/topics/whatsnew12.md)
