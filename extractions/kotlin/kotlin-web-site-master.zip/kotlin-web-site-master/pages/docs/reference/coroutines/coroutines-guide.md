---
title: docs/coroutines-guide.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/coroutines-guide.html
---

The page is moved to [topics/coroutines-guide.md](docs/topics/coroutines-guide.md)
