---
title: docs/shared-mutable-state-and-concurrency.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/shared-mutable-state-and-concurrency.html
---

The page is moved to [topics/shared-mutable-state-and-concurrency.md](docs/topics/shared-mutable-state-and-concurrency.md)
