---
title: docs/channels.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/channels.html
---

The page is moved to [topics/channels.md](docs/topics/channels.md)
