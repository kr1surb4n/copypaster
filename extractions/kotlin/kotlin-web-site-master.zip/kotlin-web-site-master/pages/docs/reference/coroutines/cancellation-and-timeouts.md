---
title: docs/cancellation-and-timeouts.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/cancellation-and-timeouts.html
---

The page is moved to [topics/cancellation-and-timeouts.md](docs/topics/cancellation-and-timeouts.md)
