---
title: docs/composing-suspending-functions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/composing-suspending-functions.html
---

The page is moved to [topics/composing-suspending-functions.md](docs/topics/composing-suspending-functions.md)
