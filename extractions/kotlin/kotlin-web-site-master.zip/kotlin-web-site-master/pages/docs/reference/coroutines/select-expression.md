---
title: docs/select-expression.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/select-expression.html
---

The page is moved to [topics/select-expression.md](docs/topics/select-expression.md)
