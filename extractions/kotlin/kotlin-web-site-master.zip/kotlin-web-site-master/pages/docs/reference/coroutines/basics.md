---
title: docs/coroutines-basics.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/coroutines-basics.html
---

The page is moved to [topics/coroutines-basics.md](docs/topics/coroutines-basics.md)
