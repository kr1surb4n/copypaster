---
title: docs/exception-handling.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/exception-handling.html
---

The page is moved to [topics/exception-handling.md](docs/topics/exception-handling.md)
