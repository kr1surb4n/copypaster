---
title: docs/operator-overloading.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/operator-overloading.html
---

The page is moved to [topics/operator-overloading.md](docs/topics/operator-overloading.md)
