---
title: docs/object-declarations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/object-declarations.html
---

The page is moved to [topics/object-declarations.md](docs/topics/object-declarations.md)
