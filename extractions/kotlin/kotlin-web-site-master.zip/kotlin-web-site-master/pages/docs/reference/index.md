---
title: docs/index.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/index.html
---

The page is moved to [topics/index.md](docs/topics/index.md)
