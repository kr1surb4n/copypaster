---
title: docs/multiplatform.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/multiplatform.html
---

The page is moved to [topics/multiplatform.md](docs/topics/multiplatform.md)
