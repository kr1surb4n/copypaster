---
title: docs/compatibility-guide-13.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/compatibility-guide-13.html
---

The page is moved to [topics/compatibility-guide-13.md](docs/topics/compatibility-guide-13.md)
