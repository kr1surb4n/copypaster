---
title: docs/mpp-configure-compilations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-configure-compilations.html
---

The page is moved to [topics/mpp-configure-compilations.md](docs/topics/mpp-configure-compilations.md)
