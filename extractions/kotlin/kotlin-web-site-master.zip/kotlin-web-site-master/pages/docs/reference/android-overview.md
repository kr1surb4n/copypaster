---
title: docs/android-overview.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/android-overview.html
---

The page is moved to [topics/android-overview.md](docs/topics/android-overview.md)
