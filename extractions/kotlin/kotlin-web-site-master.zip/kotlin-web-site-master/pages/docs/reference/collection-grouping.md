---
title: docs/collection-grouping.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-grouping.html
---

The page is moved to [topics/collection-grouping.md](docs/topics/collection-grouping.md)
