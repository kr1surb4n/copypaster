---
title: docs/native-ant.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/ant.html
---

The page is moved to [topics/ant.md](docs/topics/ant.md)
