---
title: docs/inline-classes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/inline-classes.html
---

The page is moved to [topics/inline-classes.md](docs/topics/inline-classes.md)
