---
title: docs/idioms.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/idioms.html
---

The page is moved to [topics/idioms.md](docs/topics/idioms.md)
