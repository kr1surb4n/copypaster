---
title: docs/kotlin-doc.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kotlin-doc.html
---

The page is moved to [topics/kotlin-doc.md](docs/topics/kotlin-doc.md)
