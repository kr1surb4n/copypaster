---
title: docs/typecasts.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/typecasts.html
---

The page is moved to [topics/typecasts.md](docs/topics/typecasts.md)
