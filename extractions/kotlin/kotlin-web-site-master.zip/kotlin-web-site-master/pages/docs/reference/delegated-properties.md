---
title: docs/delegated-properties.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/delegated-properties.html
---

The page is moved to [topics/delegated-properties.md](docs/topics/delegated-properties.md)
