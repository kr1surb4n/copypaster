---
title: docs/mpp-add-dependencies.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-add-dependencies.html
---

The page is moved to [topics/mpp-add-dependencies.md](docs/topics/mpp-add-dependencies.md)
