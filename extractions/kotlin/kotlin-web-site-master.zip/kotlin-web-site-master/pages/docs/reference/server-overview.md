---
title: docs/server-overview.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/server-overview.html
---

The page is moved to [topics/server-overview.md](docs/topics/server-overview.md)
