---
title: docs/mpp-publish-lib.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-publish-lib.html
---

The page is moved to [topics/mpp-publish-lib.md](docs/topics/mpp-publish-lib.md)
