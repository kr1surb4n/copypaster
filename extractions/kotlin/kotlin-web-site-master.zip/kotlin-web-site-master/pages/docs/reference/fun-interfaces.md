---
title: docs/fun-interfaces.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/fun-interfaces.html
---

The page is moved to [topics/fun-interfaces.md](docs/topics/fun-interfaces.md)
