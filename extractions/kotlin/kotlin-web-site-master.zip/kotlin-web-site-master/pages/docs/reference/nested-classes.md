---
title: docs/nested-classes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/nested-classes.html
---

The page is moved to [topics/nested-classes.md](docs/topics/nested-classes.md)
