---
title: docs/js-interop.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-interop.html
---

The page is moved to [topics/js-interop.md](docs/topics/js-interop.md)
