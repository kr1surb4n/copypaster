---
title: docs/collection-plus-minus.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-plus-minus.html
---

The page is moved to [topics/collection-plus-minus.md](docs/topics/collection-plus-minus.md)
