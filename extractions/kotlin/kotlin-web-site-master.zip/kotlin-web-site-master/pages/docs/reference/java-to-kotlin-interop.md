---
title: docs/java-to-kotlin-interop.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/java-to-kotlin-interop.html
---

The page is moved to [topics/java-to-kotlin-interop.md](docs/topics/java-to-kotlin-interop.md)
