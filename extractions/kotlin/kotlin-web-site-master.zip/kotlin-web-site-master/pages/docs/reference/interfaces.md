---
title: docs/interfaces.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/interfaces.html
---

The page is moved to [topics/interfaces.md](docs/topics/interfaces.md)
