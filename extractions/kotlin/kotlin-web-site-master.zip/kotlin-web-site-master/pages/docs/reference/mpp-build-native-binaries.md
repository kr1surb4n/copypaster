---
title: docs/mpp-build-native-binaries.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-build-native-binaries.html
---

The page is moved to [topics/mpp-build-native-binaries.md](docs/topics/mpp-build-native-binaries.md)
