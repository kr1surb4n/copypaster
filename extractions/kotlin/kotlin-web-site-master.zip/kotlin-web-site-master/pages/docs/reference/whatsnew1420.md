---
title: docs/whatsnew1420.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew1420.html
---

The page is moved to [docs/whatsnew1420.md](docs/whatsnew1420.html)
