---
title: docs/collection-elements.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-elements.html
---

The page is moved to [topics/collection-elements.md](docs/topics/collection-elements.md)
