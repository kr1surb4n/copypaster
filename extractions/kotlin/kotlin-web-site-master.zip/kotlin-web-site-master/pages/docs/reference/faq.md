---
title: docs/faq.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/faq.html
---

The page is moved to [topics/faq.md](docs/topics/faq.md)
