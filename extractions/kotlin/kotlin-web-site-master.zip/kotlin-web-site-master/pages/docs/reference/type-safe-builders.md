---
title: docs/type-safe-builders.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/type-safe-builders.html
---

The page is moved to [topics/type-safe-builders.md](docs/topics/type-safe-builders.md)
