---
title: docs/inline-functions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/inline-functions.html
---

The page is moved to [topics/inline-functions.md](docs/topics/inline-functions.md)
