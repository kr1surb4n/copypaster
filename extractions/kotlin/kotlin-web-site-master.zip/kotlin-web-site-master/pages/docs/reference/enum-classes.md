---
title: docs/enum-classes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/enum-classes.html
---

The page is moved to [topics/enum-classes.md](docs/topics/enum-classes.md)
