---
title: docs/collection-transformations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-transformations.html
---

The page is moved to [topics/collection-transformations.md](docs/topics/collection-transformations.md)
