---
title: docs/migrating-multiplatform-project-to-14.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/migrating-multiplatform-project-to-14.html
---

The page is moved to [topics/migrating-multiplatform-project-to-14.md](docs/topics/migrating-multiplatform-project-to-14.md)
