---
title: docs/opt-in-requirements.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/opt-in-requirements.html
---

The page is moved to [topics/opt-in-requirements.md](docs/topics/opt-in-requirements.md)
