---
title: docs/multi-declarations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/multi-declarations.html
---

The page is moved to [topics/multi-declarations.md](docs/topics/multi-declarations.md)
