---
title: docs/coding-conventions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/coding-conventions.html
---

The page is moved to [topics/coding-conventions.md](docs/topics/coding-conventions.md)
