---
title: docs/sequences.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/sequences.html
---

The page is moved to [topics/sequences.md](docs/topics/sequences.md)
