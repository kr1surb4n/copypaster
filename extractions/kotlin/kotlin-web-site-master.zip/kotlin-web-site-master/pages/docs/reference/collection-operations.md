---
title: docs/collection-operations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-operations.html
---

The page is moved to [topics/collection-operations.md](docs/topics/collection-operations.md)
