---
title: docs/set-operations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/set-operations.html
---

The page is moved to [topics/set-operations.md](docs/topics/set-operations.md)
