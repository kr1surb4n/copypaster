---
title: docs/null-safety.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/null-safety.html
---

The page is moved to [topics/null-safety.md](docs/topics/null-safety.md)
