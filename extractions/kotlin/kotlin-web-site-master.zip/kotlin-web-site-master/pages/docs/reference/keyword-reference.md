---
title: docs/keyword-reference.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/keyword-reference.html
---

The page is moved to [topics/keyword-reference.md](docs/topics/keyword-reference.md)
