---
title: docs/mpp-discover-project.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-discover-project.html
---

The page is moved to [topics/mpp-discover-project.md](docs/topics/mpp-discover-project.md)
