---
title: docs/basic-syntax.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/basic-syntax.html
---

The page is moved to [topics/basic-syntax.md](docs/topics/basic-syntax.md)
