---
title: docs/all-open-plugin.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/all-open-plugin.html
---

The page is moved to [topics/all-open-plugin.md](docs/topics/all-open-plugin.md)
