---
title: docs/collection-write.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-write.html
---

The page is moved to [topics/collection-write.md](docs/topics/collection-write.md)
