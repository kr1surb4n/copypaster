---
title: docs/collection-parts.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-parts.html
---

The page is moved to [topics/collection-parts.md](docs/topics/collection-parts.md)
