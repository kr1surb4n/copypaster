---
title: docs/collection-aggregate.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-aggregate.html
---

The page is moved to [topics/collection-aggregate.md](docs/topics/collection-aggregate.md)
