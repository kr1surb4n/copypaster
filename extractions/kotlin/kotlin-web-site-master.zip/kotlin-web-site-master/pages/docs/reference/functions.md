---
title: docs/functions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/functions.html
---

The page is moved to [topics/functions.md](docs/topics/functions.md)
