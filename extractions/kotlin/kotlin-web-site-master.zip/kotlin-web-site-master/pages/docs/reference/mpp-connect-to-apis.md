---
title: docs/mpp-connect-to-apis.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-connect-to-apis.html
---

The page is moved to [topics/mpp-connect-to-apis.md](docs/topics/mpp-connect-to-apis.md)
