---
title: docs/mpp-intro.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-intro.html
---

The page is moved to [topics/mpp-intro.md](docs/topics/mpp-intro.md)
