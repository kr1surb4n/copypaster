---
title: docs/whatsnew1430.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew1430.html
---

The page is moved to [topics/whatsnew1430.md](docs/topics/whatsnew1430.md)
