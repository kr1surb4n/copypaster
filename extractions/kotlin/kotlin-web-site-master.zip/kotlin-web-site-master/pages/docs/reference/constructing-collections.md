---
title: docs/constructing-collections.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/constructing-collections.html
---

The page is moved to [topics/constructing-collections.md](docs/topics/constructing-collections.md)
