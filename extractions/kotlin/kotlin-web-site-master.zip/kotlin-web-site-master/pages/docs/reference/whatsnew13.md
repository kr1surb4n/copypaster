---
title: docs/whatsnew13.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew13.html
---

The page is moved to [topics/whatsnew13.md](docs/topics/whatsnew13.md)
