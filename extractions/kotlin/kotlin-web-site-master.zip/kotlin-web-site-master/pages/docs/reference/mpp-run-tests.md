---
title: docs/mpp-run-tests.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-run-tests.html
---

The page is moved to [topics/mpp-run-tests.md](docs/topics/mpp-run-tests.md)
