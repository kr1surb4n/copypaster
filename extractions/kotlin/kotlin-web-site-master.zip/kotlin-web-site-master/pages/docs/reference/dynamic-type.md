---
title: docs/dynamic-type.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/dynamic-type.html
---

The page is moved to [topics/dynamic-type.md](docs/topics/dynamic-type.md)
