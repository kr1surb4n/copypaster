---
title: docs/extensions.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/extensions.html
---

The page is moved to [topics/extensions.md](docs/topics/extensions.md)
