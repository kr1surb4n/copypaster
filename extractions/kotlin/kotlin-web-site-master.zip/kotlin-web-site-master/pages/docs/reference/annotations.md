---
title: docs/annotations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/annotations.html
---

The page is moved to [topics/annotations.md](docs/topics/annotations.md)
