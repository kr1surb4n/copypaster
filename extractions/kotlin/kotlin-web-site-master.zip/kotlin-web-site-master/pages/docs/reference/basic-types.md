---
title: docs/basic-types.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/basic-types.html
---

The page is moved to [topics/basic-types.md](docs/topics/basic-types.md)
