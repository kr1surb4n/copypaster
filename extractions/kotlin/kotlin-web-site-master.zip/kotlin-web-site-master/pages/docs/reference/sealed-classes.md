---
title: docs/sealed-classes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/sealed-classes.html
---

The page is moved to [topics/sealed-classes.md](docs/topics/sealed-classes.md)
