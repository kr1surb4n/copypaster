---
title: docs/control-flow.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/control-flow.html
---

The page is moved to [topics/control-flow.md](docs/topics/control-flow.md)
