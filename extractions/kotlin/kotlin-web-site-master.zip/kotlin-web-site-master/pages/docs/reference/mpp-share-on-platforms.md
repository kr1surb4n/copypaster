---
title: docs/mpp-share-on-platforms.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mpp-share-on-platforms.html
---

The page is moved to [topics/mpp-share-on-platforms.md](docs/topics/mpp-share-on-platforms.md)
