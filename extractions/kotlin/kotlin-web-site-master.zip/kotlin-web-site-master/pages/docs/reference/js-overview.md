---
title: docs/js-overview.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-overview.html
---

The page is moved to [topics/js-overview.md](docs/topics/js-overview.md)
