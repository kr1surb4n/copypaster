---
title: docs/delegation.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/delegation.html
---

The page is moved to [topics/delegation.md](docs/topics/delegation.md)
