---
title: docs/comparison-to-java.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/comparison-to-java.html
---

The page is moved to [topics/comparison-to-java.md](docs/topics/comparison-to-java.md)
