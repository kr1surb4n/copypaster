---
title: docs/collection-filtering.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-filtering.html
---

The page is moved to [topics/collection-filtering.md](docs/topics/collection-filtering.md)
