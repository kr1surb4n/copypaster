---
type: doc
layout: reference
title: "Building Multiplatform Projects with Gradle"
redirect_path: https://kotlinlang.org/docs/reference/mpp-intro.html
---

Multiplatform documentation has been restructured and updated.
