---
title: docs/native-debugging.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-debugging.html
---

The page is moved to [topics/native-debugging.md](docs/topics/native-debugging.md)
