---
title: docs/native-faq.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-faq.html
---

The page is moved to [topics/native-faq.md](docs/topics/native-faq.md)
