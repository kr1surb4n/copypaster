---
title: docs/native-libraries.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-libraries.html
---

The page is moved to [topics/native-libraries.md](docs/topics/native-libraries.md)
