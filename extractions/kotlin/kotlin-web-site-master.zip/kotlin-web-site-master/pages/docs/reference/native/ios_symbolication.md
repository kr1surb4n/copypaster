---
title: docs/native-ios-symbolication.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-ios-symbolication.html
---

The page is moved to [topics/native-ios-symbolication.md](docs/topics/native-ios-symbolication.md)
