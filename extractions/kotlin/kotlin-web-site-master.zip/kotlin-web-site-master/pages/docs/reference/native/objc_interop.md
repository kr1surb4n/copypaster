---
title: docs/native-objc-interop.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-objc-interop.html
---

The page is moved to [topics/native-objc-interop.md](docs/topics/native-objc-interop.md)
