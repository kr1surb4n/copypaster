---
title: docs/native-immutability.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-immutability.html
---

The page is moved to [topics/native-immutability.md](docs/topics/native-immutability.md)
