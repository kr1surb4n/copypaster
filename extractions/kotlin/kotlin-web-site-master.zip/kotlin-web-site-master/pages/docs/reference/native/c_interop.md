---
title: docs/native-c-interop.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-c-interop.html
---

The page is moved to [topics/native-c-interop.md](docs/topics/native-c-interop.md)
