---
title: docs/native-concurrency.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-concurrency.html
---

The page is moved to [topics/native-concurrency.md](docs/topics/native-concurrency.md)
