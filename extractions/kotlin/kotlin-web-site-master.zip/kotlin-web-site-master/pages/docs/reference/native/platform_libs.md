---
title: docs/native-platform-libs.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-platform-libs.html
---

The page is moved to [topics/native-platform-libs.md](docs/topics/native-platform-libs.md)
