---
title: docs/native-cocoapods.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-cocoapods.html
---

The page is moved to [topics/native-cocoapods.md](docs/topics/native-cocoapods.md)
