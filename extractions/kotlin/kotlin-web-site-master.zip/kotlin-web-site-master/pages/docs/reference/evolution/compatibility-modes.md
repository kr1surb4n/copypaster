---
title: docs/compatibility-modes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/compatibility-modes.html
---

The page is moved to [topics/compatibility-modes.md](docs/topics/compatibility-modes.md)
