---
title: docs/components-stability-pre-1.4.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/components-stability-pre-1-4.html
---

The page is moved to [topics/components-stability-pre-1.4.md](../../../../docs/topics/components-stability-pre-1.4.md)
