---
title: docs/kotlin-evolution.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kotlin-evolution.html
---

The page is moved to [topics/kotlin-evolution.md](docs/topics/kotlin-evolution.md)
