---
title: docs/properties.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/properties.html
---

The page is moved to [topics/properties.md](docs/topics/properties.md)
