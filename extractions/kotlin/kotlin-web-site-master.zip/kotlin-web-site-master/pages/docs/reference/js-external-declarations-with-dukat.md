---
title: docs/js-external-declarations-with-dukat.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-external-declarations-with-dukat.html
---

The page is moved to [topics/js-external-declarations-with-dukat.md](docs/topics/js-external-declarations-with-dukat.md)
