---
title: docs/collection-ordering.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collection-ordering.html
---

The page is moved to [topics/collection-ordering.md](docs/topics/collection-ordering.md)
