---
type: doc
layout: reference
category: "Other"
title: "Platform-Specific Declarations"
redirect_path: https://kotlinlang.org/docs/reference/mpp-connect-to-apis.html
---

The page has been moved.
