---
title: docs/packages.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/packages.html
---

The page is moved to [topics/packages.md](docs/topics/packages.md)
