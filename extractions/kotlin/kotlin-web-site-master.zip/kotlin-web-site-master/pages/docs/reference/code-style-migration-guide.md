---
title: docs/code-style-migration-guide.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/code-style-migration-guide.html
---

The page is moved to [topics/code-style-migration-guide.md](docs/topics/code-style-migration-guide.md)
