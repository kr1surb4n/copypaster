---
title: docs/whatsnew-plugin-20203.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/whatsnew-plugin-20203.html
---

The page is moved to [topics/whatsnew-plugin-20203.md](docs/topics/whatsnew-plugin-20203.md)
