---
title: docs/ranges.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/ranges.html
---

The page is moved to [topics/ranges.md](docs/topics/ranges.md)
