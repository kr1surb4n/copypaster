---
title: docs/data-classes.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/data-classes.html
---

The page is moved to [topics/data-classes.md](docs/topics/data-classes.md)
