---
title: docs/type-aliases.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/type-aliases.html
---

The page is moved to [topics/type-aliases.md](docs/topics/type-aliases.md)
