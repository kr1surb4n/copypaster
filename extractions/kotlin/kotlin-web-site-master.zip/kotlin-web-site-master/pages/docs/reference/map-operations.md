---
title: docs/map-operations.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/map-operations.html
---

The page is moved to [topics/map-operations.md](docs/topics/map-operations.md)
