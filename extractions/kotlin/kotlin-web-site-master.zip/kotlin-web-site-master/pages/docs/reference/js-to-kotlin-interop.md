---
title: docs/js-to-kotlin-interop.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-to-kotlin-interop.html
---

The page is moved to [topics/js-to-kotlin-interop.md](docs/topics/js-to-kotlin-interop.md)
