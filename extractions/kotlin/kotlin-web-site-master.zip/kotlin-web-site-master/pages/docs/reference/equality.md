---
title: docs/equality.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/equality.html
---

The page is moved to [topics/equality.md](docs/topics/equality.md)
