---
title: docs/collections-overview.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/collections-overview.html
---

The page is moved to [topics/collections-overview.md](docs/topics/collections-overview.md)
