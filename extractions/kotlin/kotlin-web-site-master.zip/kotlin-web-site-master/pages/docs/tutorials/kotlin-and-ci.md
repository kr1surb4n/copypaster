---
title: docs/kotlin-and-ci.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kotlin-and-ci.html
---

The page is moved to [topics/kotlin-and-ci.md](docs/topics/kotlin-and-ci.md)
