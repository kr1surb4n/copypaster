---
title: docs/spring-boot-restful.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/spring-boot-restful.html
---

The page is moved to [topics/jvm/jvm-spring-boot-restful.md](../../../docs/topics/jvm/jvm-spring-boot-restful.md)
