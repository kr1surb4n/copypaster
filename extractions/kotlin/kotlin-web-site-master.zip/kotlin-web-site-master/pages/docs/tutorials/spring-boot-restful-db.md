---
title: docs/jvm-spring-boot-restful-db.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/jvm-spring-boot-restful-db.html
---

The page is moved to [topics/jvm/jvm-spring-boot-restful-db.md](../../../docs/topics/jvm/jvm-spring-boot-restful-db.md)
