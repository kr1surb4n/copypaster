---
title: docs/debug-flow-with-idea.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/debug-flow-with-idea.html
---

The page is moved to [topics/debug-flow-with-idea.md](https://github.com/Kotlin/kotlinx.coroutines/blob/master/docs/topics/debug-flow-with-idea.md)
