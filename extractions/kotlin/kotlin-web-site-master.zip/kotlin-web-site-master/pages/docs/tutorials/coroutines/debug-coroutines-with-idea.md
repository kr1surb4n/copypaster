---
title: docs/debug-coroutines-with-idea.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/debug-coroutines-with-idea.html
---

The page is moved to [topics/debug-coroutines-with-idea.md](https://github.com/Kotlin/kotlinx.coroutines/blob/master/docs/topics/debug-coroutines-with-idea.md)
