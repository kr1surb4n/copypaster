---
title: docs/competitive-programming.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/competitive-programming.html
---

The page is moved to [topics/competitive-programming.md](../../../docs/topics/competitive-programming.md)
