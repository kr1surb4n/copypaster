---
title: docs/quick-run.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/quick-run.html
---

The page is moved to [topics/run-code-snippets.md](../../../docs/topics/run-code-snippets.md)
