---
title: docs/command-line.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/command-line.html
---

The page is moved to [topics/command-line.md](../../../docs/topics/command-line.md)
