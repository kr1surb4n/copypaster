---
title: docs/getting-started.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/getting-started.html
---

The page is moved to [topics/getting-started.md](../../../docs/topics/getting-started.md)
