---
redirect_path: https://khan.github.io/kotlin-for-python-developers/#functional-programming
---