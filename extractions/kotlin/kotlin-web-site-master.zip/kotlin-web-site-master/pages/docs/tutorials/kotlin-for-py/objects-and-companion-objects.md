---
redirect_path: https://khan.github.io/kotlin-for-python-developers/#objects-and-companion-objects
---