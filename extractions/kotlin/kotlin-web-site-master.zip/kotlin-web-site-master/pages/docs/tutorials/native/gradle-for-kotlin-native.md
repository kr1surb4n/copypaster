---
type: tutorial
layout: tutorial
title:  "Gradle for Kotlin/Native"
description: "Using Gradle when working with Kotlin/Native"
authors: 
 - Hadi Hariri
 - Eugene Petrenko 
date: 2019-04-15
redirect_path: https://kotlinlang.org/docs/tutorials/native/using-gradle.html
---


The page is moved to [A Basic Kotlin/Native Application](basic-kotlin-native-app.html)

