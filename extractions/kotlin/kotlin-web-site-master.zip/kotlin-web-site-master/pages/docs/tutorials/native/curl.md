---
title: docs/curl.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/curl.html
---

The page is moved to [topics/curl.md](../../../../docs/topics/curl.md)
