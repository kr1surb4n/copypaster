---
title: docs/mapping-function-pointers-from-c.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mapping-function-pointers-from-c.html
---

The page is moved to [topics/native/mapping-function-pointers-from-c.md](../../../../docs/topics/native/mapping-function-pointers-from-c.md)
