---
type: tutorial
layout: tutorial
title:  "Interop with C Libraries"
description: "A look at how to interop with C libraries"
authors: Hadi Hariri 
date: 2018-11-20
redirect_path: https://kotlinlang.org/docs/tutorials/native/curl.html
---


The page is moved
