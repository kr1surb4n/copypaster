---
type: tutorial
layout: tutorial
title:  "Obsolete"
description: "Obsolete - Only for redirect purposes"
authors: Hadi Hariri
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/tutorials/native/using-command-line-compiler.html
---
