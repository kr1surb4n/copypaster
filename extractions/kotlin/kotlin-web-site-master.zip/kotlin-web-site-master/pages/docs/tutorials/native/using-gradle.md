---
title: docs/native-gradle.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-gradle.html
---

The page is moved to [topics/native/native-gradle.md](../../../../docs/topics/native/native-gradle.md)
