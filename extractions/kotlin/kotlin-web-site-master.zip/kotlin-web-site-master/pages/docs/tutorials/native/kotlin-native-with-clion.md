---
type: tutorial
layout: tutorial
title:  "Kotlin/Native with CLion"
description: "Using CLion for Kotlin/Native development"
authors: Hadi Hariri 
date: 2018-01-23
redirect_path: https://kotlinlang.org/docs/tutorials/native/using-command-line-compiler.html

---


The page is moved to [A Basic Kotlin/Native Application](basic-kotlin-native-app.html)


