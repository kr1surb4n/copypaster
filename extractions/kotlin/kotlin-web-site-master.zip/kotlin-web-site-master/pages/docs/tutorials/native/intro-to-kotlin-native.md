---
type: tutorial
layout: tutorial
title:  "An HTTP Client in with libcurl"
description: "Creating an HTTP client in Kotlin/Native with libcurl library"
authors: Hadi Hariri
showAuthorInfo: false
redirect_path: https://play.kotlinlang.org/hands-on/Introduction%20to%20Kotlin%20Native/

---

<!--- Do not rename this file despite no alignment with contents because of multiple redirects --->

The tutorial is stored at play.kotlinlang.org. Please open
[Introduction to Kotlin/Native](https://play.kotlinlang.org/hands-on/Introduction%20to%20Kotlin%20Native/).
