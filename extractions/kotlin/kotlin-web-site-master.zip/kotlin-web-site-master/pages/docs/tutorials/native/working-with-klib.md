---
type: tutorial
layout: tutorial
title:  "Working with Kotlin/Native Libraries"
description: "A look at how to work with Kotlin/Native libraries"
authors: Hadi Hariri 
date: 2018-01-22
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/tutorials/mpp/multiplatform-library.html
---

The page is moved
