---
title: docs/native-dynamic-libraries.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-dynamic-libraries.html
---

The page is moved to [topics/native/native-dynamic-libraries.md](../../../../docs/topics/native/native-dynamic-libraries.md)
