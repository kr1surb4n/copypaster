---
title: docs/native-get-started.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/native-get-started.html
---

The page is moved to [topics/native/native-get-started.md](../../../../docs/topics/native/native-get-started.md)
