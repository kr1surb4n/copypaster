---
type: tutorial
layout: tutorial
title:  "Targeting Multiple Platforms"
description: "Compiling with Kotlin/Native for different platforms"
authors: Eugene Petrenko
date: 2018-07-10
issue: EVAN-5121
redirect_path: https://kotlinlang.org/docs/tutorials/native/basic-kotlin-native-app.html
---

The page is moved
