---
title: docs/mapping-struct-union-types-from-c.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mapping-struct-union-types-from-c.html
---

The page is moved to [topics/native/mapping-struct-union-types-from-c.md](../../../../docs/topics/native/mapping-struct-union-types-from-c.md)
