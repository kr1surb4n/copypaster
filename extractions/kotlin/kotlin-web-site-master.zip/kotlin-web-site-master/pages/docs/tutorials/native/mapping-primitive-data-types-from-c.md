---
title: docs/mapping-primitive-data-types-from-c.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mapping-primitive-data-types-from-c.html
---

The page is moved to [topics/native/mapping-primitive-data-types-from-c.md](../../../../docs/topics/native/mapping-primitive-data-types-from-c.md)
