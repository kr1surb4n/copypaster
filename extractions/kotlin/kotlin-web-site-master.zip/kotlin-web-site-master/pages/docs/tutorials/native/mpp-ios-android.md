---
type: tutorial
layout: tutorial
title:  "Multiplatform Project: iOS and Android"
description: "Sharing Kotlin code between iOS and Android"
authors: Eugene Petrenko
date: 2019-08-11
showAuthorInfo: false
issue: EVAN-6029
redirect_path: https://kotlinlang.org/docs/mobile/create-first-app.html
---

The tutorial is moved to the new address. Please open
[Targeting iOS and Android with Kotlin Multiplatform](https://kotlinlang.org/docs/mobile/create-first-app.html)
