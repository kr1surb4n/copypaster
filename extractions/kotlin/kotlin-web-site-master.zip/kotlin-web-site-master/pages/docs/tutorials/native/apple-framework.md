---
title: docs/apple-framework.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/apple-framework.html
---

The page is moved to [topics/apple-framework.md](../../../../docs/topics/apple-framework.md)
