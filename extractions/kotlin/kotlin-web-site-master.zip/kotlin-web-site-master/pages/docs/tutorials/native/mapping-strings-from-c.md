---
title: docs/mapping-strings-from-c.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mapping-strings-from-c.html
---

The page is moved to [topics/native/mapping-strings-from-c.md](../../../../docs/topics/native/mapping-strings-from-c.md)
