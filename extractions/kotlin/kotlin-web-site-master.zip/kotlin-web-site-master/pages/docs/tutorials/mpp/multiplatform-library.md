---
title: docs/multiplatform-library.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/multiplatform-library.html
---

The page is moved to [topics/mpp/multiplatform-library.md](../../../../docs/topics/mpp/multiplatform-library.md)
