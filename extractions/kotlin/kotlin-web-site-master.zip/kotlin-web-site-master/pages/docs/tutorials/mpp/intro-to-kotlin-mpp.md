---
type: tutorial
layout: tutorial
title: "Introduction to Kotlin/Multiplatform"
description: "Introduction to Kotlin/Multiplatform"
authors: Eugene Petrenko
showAuthorInfo: false
redirect_path: https://play.kotlinlang.org/hands-on/Introduction%20to%20Kotlin%20Multiplatform/01_Introduction

---

The tutorial is moved to the new address. Please open
[Introduction to Kotlin/Multiplatform](https://play.kotlinlang.org/hands-on/Introduction%20to%20Kotlin%20Multiplatform/01_Introduction)