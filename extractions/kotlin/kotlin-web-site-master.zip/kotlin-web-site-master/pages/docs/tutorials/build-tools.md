---
title: docs/gradle.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/gradle.html
---

The page is moved to [topics/gradle.md](../../../docs/topics/gradle.md)
