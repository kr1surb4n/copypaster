---
title: docs/koans.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/koans.html
---

The page is moved to [topics/koans.md](docs/topics/koans.md)
