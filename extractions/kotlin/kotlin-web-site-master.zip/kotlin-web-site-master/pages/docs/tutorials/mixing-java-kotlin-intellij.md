---
title: docs/mixing-java-kotlin-intellij.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/mixing-java-kotlin-intellij.html
---

The page is moved to [topics/jvm/mixing-java-kotlin-intellij.md](../../../docs/topics/jvm/mixing-java-kotlin-intellij.md)
