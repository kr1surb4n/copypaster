---
title: docs/typesafe-html-dsl.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/typesafe-html-dsl.html
---

The page is moved to [topics/js/typesafe-html-dsl.md](../../../../docs/topics/js/typesafe-html-dsl.md)
