---
title: docs/using-packages-from-npm.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/using-packages-from-npm.html
---

The page is moved to [topics/js/using-packages-from-npm.md](../../../../docs/topics/js/using-packages-from-npm.md)
