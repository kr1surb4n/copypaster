---
title: docs/calling-javascript-from-kotlin.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/calling-javascript-from-kotlin.html
---
