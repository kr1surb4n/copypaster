---
type: tutorial
layout: tutorial
title:  "Debugging Kotlin in browser"
date: 2017-07-31
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/tutorials/javascript/debugging-kotlin-in-browser.html
---

The page was moved to [Debugging Kotlin/JS](../debugging-kotlin-in-browser.html)
