---
title: docs/command-line-library-js.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/command-line-library-js.html
---
