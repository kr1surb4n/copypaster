---
title: docs/dev-server-continuous-compilation.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/dev-server-continuous-compilation.html
---

The page is moved to [topics/js/dev-server-continuous-compilation.md](../../../../docs/topics/js/dev-server-continuous-compilation.md)
