---
title: docs/getting-started-with-maven.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/getting-started-with-maven.html
---
