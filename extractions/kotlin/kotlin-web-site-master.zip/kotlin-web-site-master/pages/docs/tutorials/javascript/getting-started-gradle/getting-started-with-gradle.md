---
type: tutorial
layout: tutorial
title:  "Getting Started with Kotlin and JavaScript with Gradle"
description: "A look at how to use Gradle to target JavaScript."
authors: Hadi Hariri 
date: 2016-11-04
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/tutorials/javascript/setting-up.html
---


The page was moved to [Setting up a Kotlin/JS project](../setting-up.html)
