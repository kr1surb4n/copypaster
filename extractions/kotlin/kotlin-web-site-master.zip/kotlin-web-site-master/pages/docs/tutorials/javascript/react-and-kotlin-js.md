---
type: tutorial
layout: tutorial
title:  "Building Web Applications with React and Kotlin/JS"
description: "Building Web Applications with React and Kotlin/JS"
authors: Sebastian Aigner
showAuthorInfo: false
redirect_path: https://play.kotlinlang.org/hands-on/Building%20Web%20Applications%20with%20React%20and%20Kotlin%20JS/01_Introduction

---

The tutorial is stored at play.kotlinlang.org. Please open
[Building Web Applications with React and Kotlin/JS](https://play.kotlinlang.org/hands-on/Building%20Web%20Applications%20with%20React%20and%20Kotlin%20JS/01_Introduction).