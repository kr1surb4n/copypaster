---
title: docs/debugging-kotlin-in-browser.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/debugging-kotlin-in-browser.html
---

The page is moved to [topics/js/debugging-kotlin-in-browser.md](../../../../docs/topics/js/debugging-kotlin-in-browser.md)
