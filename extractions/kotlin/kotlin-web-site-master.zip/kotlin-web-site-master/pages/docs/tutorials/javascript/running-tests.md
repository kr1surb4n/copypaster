---
title: docs/js-running-tests.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-running-tests.html
---

The page is moved to [topics/js-running-tests.md](../../../../docs/topics/js/js-running-tests.md)
