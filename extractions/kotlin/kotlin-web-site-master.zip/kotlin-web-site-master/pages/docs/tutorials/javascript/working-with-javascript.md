---
title: docs/js-project-setup.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-project-setup.html
---

The page is moved to [topics/js/working-with-javascript.md](../../../../docs/topics/js/js-project-setup.md)
