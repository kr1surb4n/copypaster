---
title: docs/running-kotlin-js.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/running-kotlin-js.html
---

The page is moved to [topics/js/running-kotlin-js.md](../../../../docs/topics/js/running-kotlin-js.md)
