---
title: docs/getting-started-with-intellij-idea.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/getting-started-with-intellij-idea.html
---
