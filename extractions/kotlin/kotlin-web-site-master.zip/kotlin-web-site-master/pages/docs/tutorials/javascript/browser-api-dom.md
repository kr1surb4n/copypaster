---
title: docs/browser-api-dom.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/browser-api-dom.html
---

The page is moved to [topics/js/browser-api-dom.md](../../../../docs/topics/js/browser-api-dom.md)
