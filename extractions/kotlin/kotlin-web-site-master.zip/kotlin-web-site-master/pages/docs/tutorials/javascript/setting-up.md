---
title: docs/js-get-started.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-get-started.html
---

The page is moved to [topics/js/js-get-started.md](../../../../docs/topics/js/js-get-started.md)
