---
title: docs/edu-tools-learner.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/edu-tools-learner.html
---

The page is moved to [topics/edu-tools-learner.md](../../../docs/topics/edu-tools-learner.md)
