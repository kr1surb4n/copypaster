---
title: docs/js-get-started.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/js-get-started.html
---

The page is moved to [topics/js/create-library-js.md](../../../docs/topics/js/js-get-started.md)
