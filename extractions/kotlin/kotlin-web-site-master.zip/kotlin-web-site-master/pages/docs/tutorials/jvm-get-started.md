---
title: docs/jvm-get-started.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/jvm-get-started.html
---

The page is moved to [topics/jvm/jvm-get-started.md](docs/topics/jvm/jvm-get-started.md)
