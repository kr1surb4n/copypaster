---
type: tutorial
layout: tutorial
title:  "Obsolete"
description: "Obsolete - Only for redirect purposes"
authors: 
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/reference/android-overview.html
---
