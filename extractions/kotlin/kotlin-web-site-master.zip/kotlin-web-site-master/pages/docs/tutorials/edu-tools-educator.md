---
title: docs/edu-tools-educator.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/edu-tools-educator.html
---

The page is moved to [topics/edu-tools-educator.md](../../../docs/topics/edu-tools-educator.md)
