---
title: docs/kotlin-pdf.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/kotlin-pdf.html
---

The page is moved to [topics/kotlin-pdf.md](../../docs/topics/kotlin-pdf.md)
