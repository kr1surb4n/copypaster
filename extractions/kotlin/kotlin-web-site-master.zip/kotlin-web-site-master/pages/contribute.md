---
title: /docs/contribute.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/contribute.html
---

The page is moved to [topics/contribute.md](../docs/topics/contribute.md)
