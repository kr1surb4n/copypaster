---
title: /docs/roadmap.html
showAuthorInfo: false
redirect_path: https://kotlinlang.org/docs/roadmap.html
---

The page is moved to [topics/roadmap.md](../docs/topics/roadmap.md)
